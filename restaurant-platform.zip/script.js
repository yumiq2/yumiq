function startOrder() {
  alert('توجيهك إلى صفحة الطلب...');
}
