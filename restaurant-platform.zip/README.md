# Restaurant Platform

This is the base structure for a multi-restaurant online ordering platform.
